import os
import json
import hashlib
import html
import time
from pathlib import Path
from urllib.parse import quote

import feedparser
import requests

TOKEN = os.environ["TELEGRAM_BOT_TOKEN"]
CHANNEL_ID = os.environ["TELEGRAM_CHANNEL_ID"]  # e.g. @IconicFootballNews
STATE_PATH = Path("seen.json")
MAX_POSTS_PER_RUN = int(os.getenv("MAX_POSTS_PER_RUN", "5"))

# RSS sources are free to read. Feeds may change or temporarily fail.
FEEDS = [
    ("Google News Arabic — football", "https://news.google.com/rss/search?q=%D9%83%D8%B1%D8%A9+%D8%A7%D9%84%D9%82%D8%AF%D9%85&hl=ar&gl=EG&ceid=EG:ar"),
    ("Google News Arabic — transfers", "https://news.google.com/rss/search?q=%D8%A7%D9%86%D8%AA%D9%82%D8%A7%D9%84%D8%A7%D8%AA+%D9%83%D8%B1%D8%A9+%D8%A7%D9%84%D9%82%D8%AF%D9%85&hl=ar&gl=EG&ceid=EG:ar"),
    ("Google News — global football (Arabic interface)", "https://news.google.com/rss/search?q=football+news&hl=ar&gl=EG&ceid=EG:ar"),
    ("Btolat", "https://www.btolat.com/rss/newsfeed"),
    ("FilGoal", "https://www.filgoal.com/section/0/rss/%D9%85%D8%B5%D8%B1"),
]

def load_seen():
    try:
        data = json.loads(STATE_PATH.read_text(encoding="utf-8"))
        return set(data if isinstance(data, list) else [])
    except (FileNotFoundError, json.JSONDecodeError):
        return set()

def save_seen(seen):
    # Keep the newest 3000 IDs to prevent state from growing indefinitely.
    STATE_PATH.write_text(
        json.dumps(list(seen)[-3000:], ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

def clean_text(value):
    value = html.unescape(str(value or ""))
    return " ".join(value.split()).strip()

def item_id(entry):
    key = entry.get("id") or entry.get("guid") or entry.get("link") or entry.get("title", "")
    return hashlib.sha256(str(key).encode("utf-8")).hexdigest()

def send_message(text):
    url = f"https://api.telegram.org/bot{TOKEN}/sendMessage"
    response = requests.post(
        url,
        data={
            "chat_id": CHANNEL_ID,
            "text": text,
            "disable_web_page_preview": "false",
        },
        timeout=25,
    )
    response.raise_for_status()
    payload = response.json()
    if not payload.get("ok"):
        raise RuntimeError(f"Telegram API error: {payload}")
    return payload

def main():
    seen = load_seen()
    found = []
    for source_name, feed_url in FEEDS:
        try:
            feed = feedparser.parse(feed_url)
            if getattr(feed, "bozo", False) and not feed.entries:
                print(f"[WARN] Feed could not be parsed: {source_name}: {getattr(feed, 'bozo_exception', '')}")
            for entry in feed.entries[:25]:
                title = clean_text(entry.get("title"))
                link = clean_text(entry.get("link"))
                if not title or not link:
                    continue
                uid = item_id(entry)
                if uid in seen:
                    continue
                summary = clean_text(entry.get("summary", ""))
                # Strip very long summaries and keep posts readable.
                if len(summary) > 500:
                    summary = summary[:497].rsplit(" ", 1)[0] + "..."
                published = clean_text(entry.get("published", ""))
                found.append({
                    "uid": uid, "title": title, "link": link,
                    "summary": summary, "source": source_name,
                    "published": published
                })
        except Exception as exc:
            print(f"[WARN] Could not read {source_name}: {exc}")

    # Preserve feed order; publish only a small batch each run to avoid flooding.
    unique = []
    used = set()
    for item in found:
        if item["uid"] not in used:
            used.add(item["uid"])
            unique.append(item)
    batch = unique[:MAX_POSTS_PER_RUN]

    if not batch:
        print("No new football stories.")
        return

    for item in reversed(batch):  # oldest first
        message = (
            "⚽ ICONIC FOOTBALL | خبر جديد\n\n"
            f"📰 {item['title']}\n"
        )
        if item["summary"]:
            message += f"\n📝 {item['summary']}\n"
        message += f"\n🌐 المصدر: {item['source']}\n🔗 {item['link']}"
        send_message(message)
        seen.add(item["uid"])
        print(f"[POSTED] {item['title']}")
        time.sleep(1)

    # Mark only posted items as seen, so overflow can be picked up next run.
    save_seen(seen)

if __name__ == "__main__":
    main()
